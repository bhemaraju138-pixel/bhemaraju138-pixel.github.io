# ATRACC Public-Rebuttal Codebook v3 (Locked Before Validation)

## Scope and estimand

The unit is one 2025 federal AI inventory record whose `is_high_impact` value is
exactly `Presumed High-Impact, but Not High-impact`. The estimand is whether the
publicly disclosed rationale carries a minimally intelligible rebuttal to the
presumption under OMB M-25-21. It is not a finding about legal compliance,
internal evidence, the system's actual effects, or agency intent.

Coders see the inventory record but not the legacy regex flags or legacy S/U/D
label. Coding uses only the disclosed rationale for the primary label. Linked
artifacts are evaluated separately and never silently change the primary label.

## Component questions

For every record, assign each component `YES`, `NO`, or `UNCLEAR` and quote the
shortest load-bearing passage. Do not infer a component from the use-case title
when it is absent from the rationale.

### P — policy predicate

`YES` only when the rationale identifies the high-impact threshold being denied
or a recognizably equivalent predicate: principal basis; legal, material,
binding, or similarly significant effect; effect on rights or safety; or a
specific consequential decision/action tied to the threshold. Merely writing
"not high impact" is `NO`.

### O — AI output and use

`YES` only when the rationale identifies what the AI supplies (for example,
alert, score, recommendation, classification, report, translation, or detected
object) and how it enters a workflow. A bare statement that humans use "the
system" is `UNCLEAR` unless the informational role is recoverable from the same
rationale.

### W-ind — independent-basis mechanism

`YES` requires both (a) an identifiable non-AI evidence source, procedure, or
institutional check and (b) an explicit relation showing that the consequential
action does not principally depend on the AI output. Generic words such as
"validate," "verify," "other information," "review," "multiple sources," or
"broader process" are not sufficient unless the source/process and constraining
role are stated. Human review of the AI output is not independent evidence by
itself.

### W-opt — non-AI alternative

`YES` only when an affected person or decision maker can actually proceed
through a non-AI path and the rationale states that this path avoids dependence
on the AI output. "Optional," "may," or "manual" without identifying the
alternative and its availability is `UNCLEAR`.

### W-nar — narrow operational mechanism

`YES` only when the rationale identifies a technically or procedurally bounded
output and explains why that bound prevents the output from serving as a
principal basis for a consequential action. Labels such as "informational
only," "recommendation only," "administrative," "pilot," or "research" are
not mechanisms without the limiting connection.

### H — human-review warrant

`YES` when human review, approval, discretion, or final decision-making is
offered as a load-bearing reason for the negative determination. Do not code H
when a human is merely identified as the recipient and the rationale instead
rests on a separately stated W mechanism.

## Primary status

- `S` (visible minimum support): P=`YES`, O=`YES`, and at least one of W-ind,
  W-opt, or W-nar=`YES`. A human-review statement may coexist with S only when a
  qualifying W mechanism is independently present.
- `D` (public defeater undefeated): H=`YES`, no W component is `YES`, and human
  oversight/discretion is a load-bearing reason offered for the exclusion.
- `U` (publicly unresolved): all other cases, including missing text, generic
  conclusion language, a predicate without an output, an output without a
  mechanism, or ambiguous evidence.

The priority rule is: test S first under the strict conjunction; otherwise D if
the human-review condition holds; otherwise U. Uncertainty is never converted
to support.

## Discourse and negation rules

1. Components must be asserted, not quoted hypotheticals or future intentions.
2. Negation attaches to its grammatical object. "Not dependent on the tool" is
   potentially load-bearing; "not solely automated" normally establishes only
   H unless a non-AI basis is also named.
3. Evidence in disconnected clauses is not automatically combined. The
   rationale must make the limiting relation intelligible.
4. Development stage, pilot status, or current non-deployment is recorded as a
   separate temporal defense, not as W, because the determination may be
   revisited when deployment changes.
5. If two reasonable readings yield different statuses, code `U` and record the
   ambiguity.

## Linked-artifact recovery

Artifacts receive a separate six-part code: retrievable; same system; temporally
applicable; same policy predicate; qualifying W mechanism; passage-level anchor.
An inventory-only U may be reported as `U→S candidate` only when all six are
`YES`. The arrow denotes recoverable public evidence, not a retroactive change
to what the inventory rationale itself disclosed.

## Required audit trail

Every coding record contains: blinded record ID, component values, primary
status, exact supporting excerpts, ambiguity note, confidence, lens name, model
and protocol version. No agreement coefficient is described as inter-rater or
human reliability unless genuinely independent human coders participate.

